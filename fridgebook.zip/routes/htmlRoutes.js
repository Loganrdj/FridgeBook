const path  = require("path");
const router = require("express").Router();


router.get("/", (req,res)=>{
    // console.log("html routers")
    res.sendFile(path.join(__dirname, "../public/index.html"));
});


function userCheck(req,res,next){
    console.log("/profile called!");
    if(req.user){
        console.log("req.user found!");
        next();
    }else{
        console.log("req.user not defined");
        res.json("User not defined!");
    }
}


router.get("/profile",userCheck,(req,res)=>{
    res.json("User Data");
})

module.exports = router;