module.exports = {
    // google oauth
    google:{
        clientID:'492502873196-nnlrsopjgrjumcfmct3qt0lvijvn8uog.apps.googleusercontent.com',
        clientSecret:'JoHjA1Pkil02KK25k57IolIu'
    },

    cookieSession:{
        sessioinKey:"fridgebookCookieSessionKey"
    },
}